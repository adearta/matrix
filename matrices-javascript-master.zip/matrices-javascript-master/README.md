For full details of this project go to
http://www.codedrome.com/one-dimensional-cellular-automaton-in-javascript/
